package onemoretry.lastone;

public class B {
	
	private A a;

}
