public interface A2 {
 
}