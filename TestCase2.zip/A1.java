public interface A1 {
 
}